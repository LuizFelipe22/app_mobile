package com.example.banco2;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ExcluirDadosActivity extends Activity {

    TextView txtnome, txtpeso, txtaltura, txtnivelpessoal, txtstatus_registro;

    SQLiteDatabase db;

    ImageView imgprimeiro, imganterior, imgproximo, imgultimo;

    Button btexcluirdados;

    int indice, numreg;

    Cursor c;

    DialogInterface.OnClickListener diExcluirDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excluir_dados);

        txtnome = findViewById(R.id.txtnome);
        txtpeso = findViewById(R.id.txtpeso);
        txtaltura = findViewById(R.id.txtaltura);
        txtnivelpessoal = findViewById(R.id.txtnivelpessoal);
        txtstatus_registro = findViewById(R.id.txtstatus_registro);

        btexcluirdados = findViewById(R.id.btexcluirdados);

        imgprimeiro = findViewById(R.id.imgprimeiro);
        imganterior = findViewById(R.id.imganterior);
        imgultimo = findViewById(R.id.imgultimo);
        imgproximo = findViewById(R.id.imgproximo);


        try{
            db = openOrCreateDatabase("TreinoFit",
                    Context.MODE_PRIVATE, null);
            c = db.query("usuarios", new String [] {"numreg", "nome", "altura", "peso", "nivel_pessoal"}, null, null, null, null, null);

            if (c.getCount() > 0){

                c.moveToFirst();
                indice = 1;
                numreg = c.getInt(0);
                txtnome.setText(c.getString(1));
                txtaltura.setText(c.getString(2));
                txtpeso.setText(c.getString(3));
                txtnivelpessoal.setText(c.getString(4));
                txtstatus_registro.setText(indice + " / " + c.getCount());
            }
            else {
                txtstatus_registro.setText("Nenhum Registro");
            }

        }
        catch (Exception e)
        {

        }

        imgprimeiro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {
                    c.moveToFirst();
                    indice = 1;
                    numreg = c.getInt(0);
                    txtnome.setText(c.getString(1));
                    txtaltura.setText(c.getString(2));
                    txtpeso.setText(c.getString(3));
                    txtnivelpessoal.setText(c.getString(4));

                    txtstatus_registro.setText(indice + " / "  + c.getCount());

                }
            }
        });

        imganterior.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {
                    if(indice > 1)
                    {
                        indice--;
                        c.moveToPrevious();

                        numreg = c.getInt(0);
                        txtnome.setText(c.getString(1));
                        txtaltura.setText(c.getString(2));
                        txtpeso.setText(c.getString(3));
                        txtnivelpessoal.setText(c.getString(4));

                        txtstatus_registro.setText(indice + " / "  + c.getCount());
                    }
                }
            }
        });

        imgproximo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {
                    if(indice != c.getCount())
                    {
                        indice++;
                        c.moveToNext();

                        numreg = c.getInt(0);
                        txtnome.setText(c.getString(1));
                        txtaltura.setText(c.getString(2));
                        txtpeso.setText(c.getString(3));
                        txtnivelpessoal.setText(c.getString(4));

                        txtstatus_registro.setText(indice + " / "  + c.getCount());
                    }
                }
            }
        });

        imgultimo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {


                    c.moveToLast();
                    indice = c.getCount();

                    numreg = c.getInt(0);
                    txtnome.setText(c.getString(1));
                    txtaltura.setText(c.getString(2));
                    txtpeso.setText(c.getString(3));
                    txtnivelpessoal.setText(c.getString(4));

                    txtstatus_registro.setText(indice + " / "  + c.getCount());
                }
            }
        });

        diExcluirDados = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                try {
                    db.delete("usuarios", "numreg = " + numreg, null);
                    CarregarDados();
                    MostraMensagem("Dados excluidos com sucesso.");
                }
                catch (Exception e)
                {
                    MostraMensagem("Erro: " + e.toString());
                }
            }
        };

        btexcluirdados.setOnClickListener(new View.OnClickListener() {

            @Override
            public void  onClick(View v) {
                if (c.getCount() > 0) {
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(ExcluirDadosActivity.this);
                    dialogo.setTitle("Confirmar");
                    dialogo.setMessage("Deseja deletar usuario?");
                    dialogo.setNegativeButton("Não", null);
                    dialogo.setPositiveButton("Sim", diExcluirDados);
                    dialogo.show();
                }
                else {
                    MostraMensagem("Não existe registros para excluir.");
                }
            }
        });

    }

    public void MostraMensagem(String str){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(ExcluirDadosActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }

    public void CarregarDados(){
        try{
            db = openOrCreateDatabase("TreinoFit",
                    Context.MODE_PRIVATE, null);
            c = db.query("usuarios", new String [] {"numreg", "nome", "altura", "peso", "nivel_pessoal"}, null, null, null, null, null);

            if (c.getCount() > 0){

                c.moveToFirst();
                indice = 1;
                numreg = c.getInt(0);
                txtnome.setText(c.getString(1));
                txtaltura.setText(c.getString(2));
                txtpeso.setText(c.getString(3));
                txtnivelpessoal.setText(c.getString(4));
                txtstatus_registro.setText(indice + " / " + c.getCount());
            }
            else {
                txtstatus_registro.setText("Nenhum Registro");
            }

        }
        catch (Exception e)
        {

        }
    }
}