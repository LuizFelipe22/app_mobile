package com.example.banco2;

import android.os.Bundle;

import android.app.Activity;
import android.os.Bundle;
import android.app.AlertDialog;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.*;
import android.widget.Spinner;

public class ActivityGravaRegistros extends Activity {

    Button btcadastrar;
    EditText ednome, edaltura, edpeso;
    Spinner ednivel;
    SQLiteDatabase db;

    String nome, peso, nivel_pessoal;
    Double altura;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grava_registros);

        btcadastrar = findViewById(R.id.btcadastrar);

        ednome = findViewById(R.id.ednome);
        edaltura = findViewById(R.id.edaltura);
        edpeso = findViewById(R.id.edpeso);
        ednivel = findViewById(R.id.ednivel);

        String[] opcoes = {"Básico", "Intermediário", "Avançado"};
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcoes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ednivel.setAdapter(adapter);

        try{
            db = openOrCreateDatabase("TreinoFit",
                    Context.MODE_PRIVATE, null);
        }
        catch (Exception e)
        {
            MostraMensagem("Erro : " + e.toString());
        }

        btcadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nome = ednome.getText().toString();
                altura = Double.parseDouble(edaltura.getText().toString());
                peso = edpeso.getText().toString();
                nivel_pessoal = ednivel.getSelectedItem().toString();

                if (altura >= 3)
                    altura /= 100;

                try {
                    db.execSQL("INSERT INTO usuarios(nome, altura, peso, nivel_pessoal) VALUES ('" + nome + "','" + altura + "','" + peso + "','" + nivel_pessoal +"')");
                    MostraMensagem("Aluno cadastrado com sucesso.");
                }
                catch (Exception e)
                {
                    MostraMensagem("Erro: " + e.toString());
                }
            }
        });
    }

    public void MostraMensagem(String str){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(ActivityGravaRegistros.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
}