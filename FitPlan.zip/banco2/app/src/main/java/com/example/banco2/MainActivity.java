package com.example.banco2;

import android.app.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    Button btcadastrardados;
    Button btexcluir;
    Button btconsultardados;
    Button btalterardados;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btalterardados = findViewById(R.id.btalterardados);
        btcadastrardados = findViewById(R.id.btcadastrardados);
        btconsultardados = findViewById(R.id.btconsultardados);
        btexcluir = findViewById(R.id.btexcluir);

        try {
            db = openOrCreateDatabase("TreinoFit", Context.MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS usuarios(numreg INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, altura DOUBLE NOT NULL, peso DOUBLE not null, nivel_pessoal TEXT NOT NULL)");


        } catch (Exception e) {
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                    dialogo.setTitle("Erro")
                           .setMessage("" + e.toString())
                           .setNeutralButton("OK", null)
                           .show();
        }

        btexcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent acticityExcluirDados = new Intent(MainActivity.this, ExcluirDadosActivity.class);
                MainActivity.this.startActivity(acticityExcluirDados);
            }
        });

        btcadastrardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent acticityGravarDados = new Intent(MainActivity.this, ActivityGravaRegistros.class);
                MainActivity.this.startActivity(acticityGravarDados);
            }
        });

        btconsultardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent acticityConsultaDados = new Intent(MainActivity.this, ActivityConsultaDados.class);
                MainActivity.this.startActivity(acticityConsultaDados);
            }
        });

        btalterardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent alterarDados2Activity = new Intent(MainActivity.this, AlterarDados2Activity.class);
                MainActivity.this.startActivity(alterarDados2Activity);
            }
        });
    }
}