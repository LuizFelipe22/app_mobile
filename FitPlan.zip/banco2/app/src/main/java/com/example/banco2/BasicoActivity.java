package com.example.banco2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.Activity;

public class BasicoActivity extends Activity {
    TextView txtmusculo, txtexplicacao1, txtexplicacao2, txtexercico1, txtexercico2, txtstatus_registro;
    Button bttutorial1, bttutorial2;
    ImageView imgprimeiro, imganterior, imgproximo, imgultimo;

    Intent intent;

    int indice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basico);

        bttutorial1 = findViewById(R.id.bttutorial1);
        bttutorial2 = findViewById(R.id.bttutorial2);

        txtmusculo = findViewById(R.id.txtmusculo);
        txtexplicacao1 = findViewById(R.id.txtexplicacao1);
        txtexplicacao2 = findViewById(R.id.txtexplicacao2);
        txtexercico1 = findViewById(R.id.txtexercico1);
        txtexercico2 = findViewById(R.id.txtexercico2);
        txtstatus_registro = findViewById(R.id.txtstatus_registro);

        imgprimeiro = findViewById(R.id.imgprimeiro);
        imganterior = findViewById(R.id.imganterior);
        imgultimo = findViewById(R.id.imgultimo);
        imgproximo = findViewById(R.id.imgproximo);

        String[] musculos = {"Ombro", "Peito", "Tríceps", "Bíceps", "Pernas", "Costas"};
        String[] exercicio1 = {"Elevação Lateral com Halteres:", "Supino com Halteres no Banco Plano:", "Extensão de Tríceps com Halter:", "Rosca Alternada com Halteres:", "Agachamento Livre:", "Remada Unilateral com Halter:"};
        String[] exercicio2 = {"Desenvolvimento com Halteres Sentado:", "Flexões de Braço:", "Tríceps no Banco (Bench Dips):", "Rosca Direta com Barra:", "Leg Press:", "Puxada Frontal no Pulley:"};

        String[] explicacao1= {
                "2-3 séries de 10-12 repetições, com pesos leves. Este exercício fortalece a porção lateral do ombro.",
                "2-3 séries de 10-12 repetições. Exercício base para desenvolver força no peito.",
                "2-3 séries de 12-15 repetições. Pode ser feito sentado ou em pé.", "2-3 séries de 10-12 repetições para cada braço.",
                "2-3 séries de 10-12 repetições para cada braço.",
                "2-3 séries de 12-15 repetições com peso corporal.",
                "2-3 séries de 10-12 repetições para cada lado."
        };
        String[] explicacao2= {
                "2-3 séries de 8-10 repetições. Trabalha a parte frontal e lateral do ombro.",
                "3 séries de 10-15 repetições. Exercício básico com peso corporal que trabalha peito, ombros e tríceps.",
                "2-3 séries de 10-12 repetições com peso corporal, usando um banco.",
                "2-3 séries de 10 repetições, usando uma barra reta ou W.",
                "3 séries de 10-12 repetições, utilizando carga leve.",
                "3 séries de 12 repetições, para trabalhar a largura das costas."
        };

        String[] tutorial1 = {
                "https://www.youtube.com/watch?v=ORparUDksUk",
                "https://www.youtube.com/watch?v=fbupGf-T4KM",
                "https://www.youtube.com/watch?v=QOj3e-BKFs4",
                "https://www.youtube.com/watch?v=0JA60myGCxw",
                "https://www.youtube.com/watch?v=86ZW7tmmLuU",
                "https://www.youtube.com/watch?v=m4h4jT9patY"
        };
        String[] tutorial2 = {
                "https://www.youtube.com/watch?v=V7rw4dRMw2M",
                "https://www.youtube.com/watch?v=dHgoYiCraCw",
                "https://www.youtube.com/watch?v=GM21qkns-Ao",
                "https://www.youtube.com/watch?v=dbggZAwJtNU",
                "https://www.youtube.com/watch?v=HilJxAnbWxA",
                "https://www.youtube.com/watch?v=t9TfOQEQaCg"
        };


        indice = 0;
        txtmusculo.setText(musculos[indice]);
        txtexercico1.setText(exercicio1[indice]);
        txtexercico2.setText(exercicio2[indice]);
        txtexplicacao1.setText(explicacao1[indice]);
        txtexplicacao2.setText(explicacao2[indice]);
        txtstatus_registro.setText((indice + 1) + " / " + 6);

        imgprimeiro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                indice = 0;
                txtmusculo.setText(musculos[indice]);
                txtexercico1.setText(exercicio1[indice]);
                txtexercico2.setText(exercicio2[indice]);
                txtexplicacao1.setText(explicacao1[indice]);
                txtexplicacao2.setText(explicacao2[indice]);
                txtstatus_registro.setText((indice + 1) + " / " + 6);
            }
        });

        imganterior.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(indice >= 1)
                {
                    indice--;
                    txtmusculo.setText(musculos[indice]);
                    txtexercico1.setText(exercicio1[indice]);
                    txtexercico2.setText(exercicio2[indice]);
                    txtexplicacao1.setText(explicacao1[indice]);
                    txtexplicacao2.setText(explicacao2[indice]);
                    txtstatus_registro.setText((indice + 1) + " / " + 6);
                }
            }
        });

        imgproximo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(indice < 5)
                {
                    indice++;
                    txtmusculo.setText(musculos[indice]);
                    txtexercico1.setText(exercicio1[indice]);
                    txtexercico2.setText(exercicio2[indice]);
                    txtexplicacao1.setText(explicacao1[indice]);
                    txtexplicacao2.setText(explicacao2[indice]);
                    txtstatus_registro.setText((indice + 1) + " / " + 6);
                }
            }
        });

        imgultimo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                indice = 5;
                txtmusculo.setText(musculos[indice]);
                txtexercico1.setText(exercicio1[indice]);
                txtexercico2.setText(exercicio2[indice]);
                txtexplicacao1.setText(explicacao1[indice]);
                txtexplicacao2.setText(explicacao2[indice]);
                txtstatus_registro.setText((indice + 1) + " / " + 6);
            }
        });

        bttutorial1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(tutorial1[indice]));
                startActivity(intent);
            }
        });

        bttutorial2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(tutorial2[indice]));
                startActivity(intent);
            }
        });
    }
}