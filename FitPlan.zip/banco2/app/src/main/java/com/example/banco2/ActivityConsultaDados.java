package com.example.banco2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import android.app.Activity;

public class ActivityConsultaDados extends Activity {

    TextView txtnome, txtaltura, txtpeso, txtnivelpessoal, txtimc, txtstatus_registro;

    SQLiteDatabase db;

    ImageView imgprimeiro, imganterior, imgproximo, imgultimo;
    Button btconsultartreino;

    int indice;
    double imc;
    String nivelImc;

    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta_dados);

        txtnome = findViewById(R.id.txtnome);
        txtpeso = findViewById(R.id.txtpeso);
        txtaltura = findViewById(R.id.txtaltura);
        txtnivelpessoal = findViewById(R.id.txtnivelpessoal);
        txtstatus_registro = findViewById(R.id.txtstatus_registro);
        txtimc = findViewById(R.id.txtimc);

        txtnome.setText("");
        txtpeso.setText("");
        txtaltura.setText("");
        txtnivelpessoal.setText("");
        txtimc.setText("");

        imgprimeiro = findViewById(R.id.imgprimeiro);
        imganterior = findViewById(R.id.imganterior);
        imgultimo = findViewById(R.id.imgultimo);
        imgproximo = findViewById(R.id.imgproximo);

        btconsultartreino = findViewById(R.id.btconsultartreino);


        try{
            db = openOrCreateDatabase("TreinoFit",
                    Context.MODE_PRIVATE, null);
            c = db.query("usuarios", new String [] {"numreg", "nome", "altura", "peso", "nivel_pessoal"}, null, null, null, null, null);

            if (c.getCount() > 0){

                c.moveToFirst();
                indice = 1;
                txtnome.setText(c.getString(1));
                txtaltura.setText(c.getString(2));
                txtpeso.setText(c.getString(3));
                txtnivelpessoal.setText(c.getString(4));

                imc = c.getDouble(3) / (c.getDouble(2) * c.getDouble(2));

                if (imc < 18.5)
                    nivelImc = "Abaixo do peso";
                else if (imc >= 18.5 && imc <= 24.9)
                    nivelImc = "Peso normal";
                else if (imc >= 25 && imc <= 29.9)
                    nivelImc = "Sobrepeso";
                else if (imc > 29.9)
                    nivelImc = "Obesidade";

                String formatValor = String.format("%.2f", imc);
                txtimc.setText(formatValor + " | Nível: " + nivelImc);
                txtstatus_registro.setText(indice + " / " + c.getCount());
            }
            else {
                txtstatus_registro.setText("Nenhum Registro");
            }

        }
        catch (Exception e)
        {

        }
//        finally {
//            if (c != null) {
//                c.close();
//            }
//            if (db != null) {
//                db.close();
//            }
//        }

        imgprimeiro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {
                    c.moveToFirst();
                    indice = 1;

                    txtnome.setText(c.getString(1));
                    txtaltura.setText(c.getString(2));
                    txtpeso.setText(c.getString(3));
                    txtnivelpessoal.setText(c.getString(4));
                    imc = c.getDouble(3) / (c.getDouble(2) * c.getDouble(2));

                    if (imc < 18.5)
                        nivelImc = "Abaixo do peso";
                    else if (imc >= 18.5 && imc <= 24.9)
                        nivelImc = "Peso normal";
                    else if (imc >= 25 && imc <= 29.9)
                        nivelImc = "Sobrepeso";
                    else if (imc > 29.9)
                        nivelImc = "Obesidade";

                    String formatValor = String.format("%.2f", imc);
                    txtimc.setText(formatValor + " | Nível: " + nivelImc);

                    txtstatus_registro.setText(indice + " / "  + c.getCount());

                }
            }
        });

        imganterior.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {
                    if(indice > 1)
                    {
                        indice--;
                        c.moveToPrevious();

                        txtnome.setText(c.getString(1));
                        txtaltura.setText(c.getString(2));
                        txtpeso.setText(c.getString(3));
                        txtnivelpessoal.setText(c.getString(4));
                        imc = c.getDouble(3) / (c.getDouble(2) * c.getDouble(2));

                        if (imc < 18.5)
                            nivelImc = "Abaixo do peso";
                        else if (imc >= 18.5 && imc <= 24.9)
                            nivelImc = "Peso normal";
                        else if (imc >= 25 && imc <= 29.9)
                            nivelImc = "Sobrepeso";
                        else if (imc > 29.9)
                            nivelImc = "Obesidade";

                        String formatValor = String.format("%.2f", imc);
                        txtimc.setText(formatValor + " | Nível: " + nivelImc);

                        txtstatus_registro.setText(indice + " / "  + c.getCount());
                    }
                }
            }
        });

        imgproximo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {
                    if(indice != c.getCount())
                    {
                        indice++;
                        c.moveToNext();

                        txtnome.setText(c.getString(1));
                        txtaltura.setText(c.getString(2));
                        txtpeso.setText(c.getString(3));
                        txtnivelpessoal.setText(c.getString(4));
                        imc = c.getDouble(3) / (c.getDouble(2) * c.getDouble(2));

                        if (imc < 18.5)
                            nivelImc = "Abaixo do peso";
                        else if (imc >= 18.5 && imc <= 24.9)
                            nivelImc = "Peso normal";
                        else if (imc >= 25 && imc <= 29.9)
                            nivelImc = "Sobrepeso";
                        else if (imc > 29.9)
                            nivelImc = "Obesidade";

                        String formatValor = String.format("%.2f", imc);
                        txtimc.setText(formatValor + " | Nível: " + nivelImc);

                        txtstatus_registro.setText(indice + " / "  + c.getCount());
                    }
                }
            }
        });

        imgultimo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (c.getCount() > 0)
                {


                    c.moveToLast();
                    indice = c.getCount();

                    txtnome.setText(c.getString(1));
                    txtaltura.setText(c.getString(2));
                    txtpeso.setText(c.getString(3));
                    txtnivelpessoal.setText(c.getString(4));
                    imc = c.getDouble(3) / (c.getDouble(2) * c.getDouble(2));

                    if (imc < 18.5)
                        nivelImc = "Abaixo do peso";
                    else if (imc >= 18.5 && imc <= 24.9)
                        nivelImc = "Peso normal";
                    else if (imc >= 25 && imc <= 29.9)
                        nivelImc = "Sobrepeso";
                    else if (imc > 29.9)
                        nivelImc = "Obesidade";

                    String formatValor = String.format("%.2f", imc);
                    txtimc.setText(formatValor + " | Nível: " + nivelImc);

                    txtstatus_registro.setText(indice + " / "  + c.getCount());
                }
            }
        });

        btconsultartreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nivelTreinamento = c.getString(4);

                if (nivelTreinamento.equals("Básico")){
                    Intent basicoActivity = new Intent(ActivityConsultaDados.this, BasicoActivity.class);
                    ActivityConsultaDados.this.startActivity(basicoActivity);
                }else if (nivelTreinamento.equals("Intermediário")){
                    Intent intermediarioActivity = new Intent(ActivityConsultaDados.this, IntermediarioActivity.class);
                    ActivityConsultaDados.this.startActivity(intermediarioActivity);
                }else if (nivelTreinamento.equals("Avançado")){
                    Intent avancadoActivity = new Intent(ActivityConsultaDados.this, AvancadoActivity.class);
                    ActivityConsultaDados.this.startActivity(avancadoActivity);
                }
            }
        });

    }

    public void MostraMensagem(String str){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(ActivityConsultaDados.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
}