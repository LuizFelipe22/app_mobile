package com.example.banco2;

import android.content.Context;
import android.os.Bundle;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;

public class AvancadoActivity extends Activity {

    TextView txtmusculo, txtexplicacao1, txtexplicacao2, txtexercico1, txtexercico2, txtstatus_registro;
    Button bttutorial1, bttutorial2;
    ImageView imgprimeiro, imganterior, imgproximo, imgultimo;

    Intent intent;

    int indice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avancado);

        bttutorial1 = findViewById(R.id.bttutorial1);
        bttutorial2 = findViewById(R.id.bttutorial2);

        txtmusculo = findViewById(R.id.txtmusculo);
        txtexplicacao1 = findViewById(R.id.txtexplicacao1);
        txtexplicacao2 = findViewById(R.id.txtexplicacao2);
        txtexercico1 = findViewById(R.id.txtexercico1);
        txtexercico2 = findViewById(R.id.txtexercico2);
        txtstatus_registro = findViewById(R.id.txtstatus_registro);

        imgprimeiro = findViewById(R.id.imgprimeiro);
        imganterior = findViewById(R.id.imganterior);
        imgultimo = findViewById(R.id.imgultimo);
        imgproximo = findViewById(R.id.imgproximo);

        String[] musculos = {"Ombro", "Peito", "Tríceps", "Bíceps", "Pernas", "Costas"};

        String[] exercicio1 = {
                "Arnold Press:",
                "Supino com Barra no Banco Inclinado:",
                "Tríceps na Paralela (Dips):",
                "Rosca Concentrada:",
                "Agachamento Búlgaro:",
                "Barra Fixa (Pull-Ups):"
        };

        String[] exercicio2 = {
                "Desenvolvimento com Halteres Unilateral:",
                "Flexão com Peso (com Carga Adicional):",
                "Extensão de Tríceps com Corda no Pulley:",
                "Rosca 21 (Método 21):",
                "Levantamento Terra:",
                "Remada com Cabo Sentado:"
        };

        String[] explicacao1 = {
                "3-4 séries de 10-12 repetições. Este exercício trabalha o ombro completo, incluindo as três cabeças.",
                "3-4 séries de 6-8 repetições. Aumenta a carga e o foco na parte superior do peito.",
                "3-4 séries de 8-10 repetições, com ou sem carga adicional.",
                "3-4 séries de 12 repetições, feita sentado com o cotovelo apoiado na perna.",
                "3-4 séries de 8-10 repetições para cada perna, usando halteres ou barra.",
                "3-4 séries de 8-10 repetições. Pode adicionar carga se necessário."
        };

        String[] explicacao2 = {
                "3-4 séries de 12 repetições, adicionando intensidade ao exercício.",
                "4 séries de 12-15 repetições, colocando carga nas costas ou nos ombros.",
                "3-4 séries de 12 repetições, usando carga moderada a alta.",
                "3 séries de 21 repetições (7 na parte baixa, 7 na parte alta e 7 no movimento completo).",
                "4 séries de 8 repetições, ótimo para trabalhar toda a parte posterior.",
                "4 séries de 10-12 repetições, com carga moderada a alta."
        };

        String[] tutorial1 = {
                "https://www.youtube.com/watch?v=d4dy7O2KLhw",
                "https://www.youtube.com/watch?v=WP1VLAt8hbM",
                "https://www.youtube.com/watch?v=LJz40nTE_sI",
                "https://www.youtube.com/watch?v=PcwdHVhWY3s",
                "https://www.youtube.com/watch?v=IGf9fR4Y7Iw",
                "https://www.youtube.com/watch?v=oH-NrOccUOg"
        };

        String[] tutorial2 = {
                "https://www.youtube.com/watch?v=6R75PUsHQxA",
                "https://youtube.com/shorts/6jWSWFKeOX0?si=jxvJOd5YP144CqgQ",
                "https://www.youtube.com/watch?v=sTaIlf8WGjg",
                "https://www.youtube.com/watch?v=nC-US9vOHz8",
                "https://www.youtube.com/watch?v=50AkPBZwACQ",
                "https://www.youtube.com/watch?v=f8AVh4VBbos"
        };

        indice = 0;
        txtmusculo.setText(musculos[indice]);
        txtexercico1.setText(exercicio1[indice]);
        txtexercico2.setText(exercicio2[indice]);
        txtexplicacao1.setText(explicacao1[indice]);
        txtexplicacao2.setText(explicacao2[indice]);
        txtstatus_registro.setText((indice + 1) + " / " + 6);

        imgprimeiro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                indice = 0;
                txtmusculo.setText(musculos[indice]);
                txtexercico1.setText(exercicio1[indice]);
                txtexercico2.setText(exercicio2[indice]);
                txtexplicacao1.setText(explicacao1[indice]);
                txtexplicacao2.setText(explicacao2[indice]);
                txtstatus_registro.setText((indice + 1) + " / " + 6);
            }
        });

        imganterior.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(indice >= 1)
                {
                    indice--;
                    txtmusculo.setText(musculos[indice]);
                    txtexercico1.setText(exercicio1[indice]);
                    txtexercico2.setText(exercicio2[indice]);
                    txtexplicacao1.setText(explicacao1[indice]);
                    txtexplicacao2.setText(explicacao2[indice]);
                    txtstatus_registro.setText((indice + 1) + " / " + 6);
                }
            }
        });

        imgproximo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(indice < 5)
                {
                    indice++;
                    txtmusculo.setText(musculos[indice]);
                    txtexercico1.setText(exercicio1[indice]);
                    txtexercico2.setText(exercicio2[indice]);
                    txtexplicacao1.setText(explicacao1[indice]);
                    txtexplicacao2.setText(explicacao2[indice]);
                    txtstatus_registro.setText((indice + 1) + " / " + 6);
                }
            }
        });

        imgultimo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                indice = 5;
                txtmusculo.setText(musculos[indice]);
                txtexercico1.setText(exercicio1[indice]);
                txtexercico2.setText(exercicio2[indice]);
                txtexplicacao1.setText(explicacao1[indice]);
                txtexplicacao2.setText(explicacao2[indice]);
                txtstatus_registro.setText((indice + 1) + " / " + 6);
            }
        });

        bttutorial1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(tutorial1[indice]));
                startActivity(intent);
            }
        });

        bttutorial2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(tutorial2[indice]));
                startActivity(intent);
            }
        });
    }
}