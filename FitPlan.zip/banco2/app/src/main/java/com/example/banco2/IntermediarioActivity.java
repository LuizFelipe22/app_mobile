package com.example.banco2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.Activity;

public class IntermediarioActivity extends Activity {

    TextView txtmusculo, txtexplicacao1, txtexplicacao2, txtexercico1, txtexercico2, txtstatus_registro;
    Button bttutorial1, bttutorial2;
    ImageView imgprimeiro, imganterior, imgproximo, imgultimo;

    Intent intent;

    int indice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intermediario);

        bttutorial1 = findViewById(R.id.bttutorial1);
        bttutorial2 = findViewById(R.id.bttutorial2);

        txtmusculo = findViewById(R.id.txtmusculo);
        txtexplicacao1 = findViewById(R.id.txtexplicacao1);
        txtexplicacao2 = findViewById(R.id.txtexplicacao2);
        txtexercico1 = findViewById(R.id.txtexercico1);
        txtexercico2 = findViewById(R.id.txtexercico2);
        txtstatus_registro = findViewById(R.id.txtstatus_registro);

        imgprimeiro = findViewById(R.id.imgprimeiro);
        imganterior = findViewById(R.id.imganterior);
        imgultimo = findViewById(R.id.imgultimo);
        imgproximo = findViewById(R.id.imgproximo);


        String[] musculos = {"Ombro", "Peito", "Tríceps", "Bíceps", "Pernas", "Costas"};

        String[] exercicio1 = {
                "Elevação Frontal Alternada com Halteres:",
                "Supino Inclinado com Halteres:",
                "Tríceps Francês com Barra:",
                "Rosca Martelo com Halteres:",
                "Agachamento com Barra:",
                "Remada Curvada com Barra:"
        };

        String[] exercicio2 = {
                "Desenvolvimento com Barra em Pé:",
                "Crucifixo com Halteres no Banco Plano:",
                "Tríceps Testa com Halteres:",
                "Rosca Scott (Bíceps no Banco):",
                "Passada (Afundo):",
                "Puxada Aberta no Pulley:"
        };

        String[] explicacao1 = {
                "3 séries de 10-12 repetições para cada braço, com pesos moderados.",
                "3 séries de 8-10 repetições. Trabalha a parte superior do peito.",
                "3 séries de 10-12 repetições. A barra aumenta a intensidade e exige mais controle.",
                "3 séries de 10-12 repetições. Trabalha a porção lateral e a braquial.",
                "3 séries de 10 repetições. Adiciona carga para desenvolver força e volume.",
                "3 séries de 10 repetições, usando carga moderada."
        };

        String[] explicacao2 = {
                "3 séries de 8-10 repetições. É mais desafiador devido ao equilíbrio e à maior carga.",
                "3 séries de 10-12 repetições. Foca na abertura e alongamento do peito.",
                "3 séries de 10-12 repetições, deitado em um banco plano.",
                "3 séries de 10 repetições, para focar na parte inferior do bíceps.",
                "3 séries de 10 repetições para cada perna, usando halteres.",
                "3 séries de 10 repetições, focando na parte superior das costas."
        };

        String[] tutorial1 = {
                "https://www.youtube.com/watch?v=g-bomxDDfGU",
                "https://www.youtube.com/watch?v=F4Q1g2z8MWM",
                "https://www.youtube.com/watch?v=SI-THv1gZZQ",
                "https://www.youtube.com/watch?v=5vPGH1uTtbs",
                "https://www.youtube.com/watch?v=72K6AMJWm4Y",
                "https://www.youtube.com/watch?v=TfxJMertfsw"
        };

        String[] tutorial2 = {
                "https://www.youtube.com/watch?v=OX-GAShzWvE",
                "https://www.youtube.com/watch?v=_kpKlYexyXs",
                "https://www.youtube.com/watch?v=emY8deCFVRo",
                "https://www.youtube.com/watch?v=0FPOPvuXDp8",
                "https://www.youtube.com/watch?v=AC61Lri9jxQ",
                "https://www.youtube.com/watch?v=9FFLBDWXSZA"
        };

        indice = 0;
        txtmusculo.setText(musculos[indice]);
        txtexercico1.setText(exercicio1[indice]);
        txtexercico2.setText(exercicio2[indice]);
        txtexplicacao1.setText(explicacao1[indice]);
        txtexplicacao2.setText(explicacao2[indice]);
        txtstatus_registro.setText((indice + 1) + " / " + 6);

        imgprimeiro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                indice = 0;
                txtmusculo.setText(musculos[indice]);
                txtexercico1.setText(exercicio1[indice]);
                txtexercico2.setText(exercicio2[indice]);
                txtexplicacao1.setText(explicacao1[indice]);
                txtexplicacao2.setText(explicacao2[indice]);
                txtstatus_registro.setText((indice + 1) + " / " + 6);
            }
        });

        imganterior.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(indice >= 1)
                {
                    indice--;
                    txtmusculo.setText(musculos[indice]);
                    txtexercico1.setText(exercicio1[indice]);
                    txtexercico2.setText(exercicio2[indice]);
                    txtexplicacao1.setText(explicacao1[indice]);
                    txtexplicacao2.setText(explicacao2[indice]);
                    txtstatus_registro.setText((indice + 1) + " / " + 6);
                }
            }
        });

        imgproximo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(indice < 5)
                {
                    indice++;
                    txtmusculo.setText(musculos[indice]);
                    txtexercico1.setText(exercicio1[indice]);
                    txtexercico2.setText(exercicio2[indice]);
                    txtexplicacao1.setText(explicacao1[indice]);
                    txtexplicacao2.setText(explicacao2[indice]);
                    txtstatus_registro.setText((indice + 1) + " / " + 6);
                }
            }
        });

        imgultimo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                indice = 6;
                txtmusculo.setText(musculos[indice]);
                txtexercico1.setText(exercicio1[indice]);
                txtexercico2.setText(exercicio2[indice]);
                txtexplicacao1.setText(explicacao1[indice]);
                txtexplicacao2.setText(explicacao2[indice]);
                txtstatus_registro.setText((indice + 1) + " / " + 6);
            }
        });

        bttutorial1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(tutorial1[indice]));
                startActivity(intent);
            }
        });

        bttutorial2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(tutorial2[indice]));
                startActivity(intent);
            }
        });
    }
}